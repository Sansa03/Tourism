// inisiasi variable DOM yang akan kita eksekusi
const btnOpen = document.querySelector('.btn-open');
const btnClose = document.querySelector('.btn-close');
const fullNavItem = document.querySelector('.full-nav-item');

// jalankan fungsi ketika hamburger menu di klik
btnOpen.addEventListener('click', () => {
    // tambahkan class baru pada navbar area
    fullNavItem.classList.add('show-full-nav-item');
    // tambahkan class baru pada bagian content
    document.querySelector('.wrapper-header').classList.add('swipe-wrapper-header');
    if (fullNavItem.classList.contains('show-full-nav-item')) {
        // tampilkan tombol close
        btnClose.style.display = 'block';
        // sembunyikan tombol open
        btnOpen.style.display = 'none';
    };
    // buat function untuk menjalankan fungsi tombol close
    activateBtnClose();
});

// menjalankan fungsi tombol close
function activateBtnClose() {
    btnClose.addEventListener('click', () => {
        // hapus class pada navbar area
        fullNavItem.classList.remove('show-full-nav-item');
        // hapus class pada bagian content
        document.querySelector('.wrapper-header').classList.remove('swipe-wrapper-header');
        if (!fullNavItem.classList.contains('show-full-nav-item')) {
            // sembunyikan tombol close
            btnClose.style.display = 'none';
            // tampilkan tombol open
            btnOpen.style.display = 'block';
        };
    });
};